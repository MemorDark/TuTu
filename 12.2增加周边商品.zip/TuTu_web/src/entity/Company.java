package entity;

public class Company {
	private int id;
	private String address;
	private String tel;
	private String businessRegistrationNo;
	private String organizationCode;
	private String taxRegistrationCertificate;
	private String legalPerson;
	private String name;
	private String loginName;
	public int getId() {
		return id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getBusinessRegistrationNo() {
		return businessRegistrationNo;
	}
	public void setBusinessRegistrationNo(String businessRegistrationNo) {
		this.businessRegistrationNo = businessRegistrationNo;
	}
	public String getOrganizationCode() {
		return organizationCode;
	}
	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}
	public String getTaxRegistrationCertificate() {
		return taxRegistrationCertificate;
	}
	public void setTaxRegistrationCertificate(String taxRegistrationCertificate) {
		this.taxRegistrationCertificate = taxRegistrationCertificate;
	}
	public String getLegalPerson() {
		return legalPerson;
	}
	public void setLegalPerson(String legalPerson) {
		this.legalPerson = legalPerson;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public Company(int id, String address, String tel, String businessRegistrationNo,
			String organizationCode, String taxRegistrationCertificate, String legalPerson, String name,
			String loginName) {
		super();
		this.id = id;
		this.address = address;
		this.tel = tel;
		this.businessRegistrationNo = businessRegistrationNo;
		this.organizationCode = organizationCode;
		this.taxRegistrationCertificate = taxRegistrationCertificate;
		this.legalPerson = legalPerson;
		this.name = name;
		this.loginName = loginName;
	}
	public Company() {
		super();
	}
}
