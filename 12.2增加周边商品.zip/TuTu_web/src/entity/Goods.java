package entity;

public class Goods {
	private int id;
	private String name;
	private String[] roughImgPaths;
	private double price;
	private int companyId;
	private String category;
	private String args;
	private String[] detailedImgPaths;
	private String repairInfo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getRoughImgPaths() {
		return roughImgPaths;
	}
	public void setRoughImgPaths(String[] roughImgPaths) {
		this.roughImgPaths = roughImgPaths;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getArgs() {
		return args;
	}
	public void setArgs(String args) {
		this.args = args;
	}
	public String[] getDetailedImgPaths() {
		return detailedImgPaths;
	}
	public void setDetailedImgPaths(String[] detailedImgPaths) {
		this.detailedImgPaths = detailedImgPaths;
	}
	public String getRepairInfo() {
		return repairInfo;
	}
	public void setRepairInfo(String repairInfo) {
		this.repairInfo = repairInfo;
	}
	public Goods(int id, String name, String[] roughImgPaths, double price, int companyId, String category,
			String args, String[] detailedImgPaths, String repairInfo) {
		super();
		this.id = id;
		this.name = name;
		this.roughImgPaths = roughImgPaths;
		this.price = price;
		this.companyId = companyId;
		this.category = category;
		this.args = args;
		this.detailedImgPaths = detailedImgPaths;
		this.repairInfo = repairInfo;
	}
	public Goods() {
		super();
	}
}
