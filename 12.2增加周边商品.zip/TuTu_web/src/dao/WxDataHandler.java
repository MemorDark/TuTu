package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;
import util.DBUtil;
import util.GoodsUtil;

public class WxDataHandler {
	public static JSONObject get(JSONObject json) {
		JSONObject returnData=null;
		Map<String, Object> map=new HashMap<>();
		int dataType=json.getInt("dataType");
		try {
			Connection connection=DBUtil.getConnection();
			if(dataType==1) {
				//getGoodsRoughInfo
				int id=json.getInt("id");
				String sql="select * from goods where id=?;";
				PreparedStatement prep=connection.prepareStatement(sql);
				prep.setInt(1, id);
				ResultSet rst=prep.executeQuery();
				if(rst.next()) {
					map.put("code", 1);
					map.put("roughImgPaths", GoodsUtil.transGoodsInfoImagePaths(rst.getString("roughImgPaths"), id));
					map.put("name", rst.getString("name"));
					map.put("price", rst.getDouble("price"));
				}
				else
					map.put("code", 0);
				prep.close();
				rst.close();
				String sql2="update goods set queryTime=queryTime+1 where id=?";
				prep=connection.prepareStatement(sql2);
				prep.setInt(1, id);
				prep.execute();
				prep.close();
			}
			else if(dataType==2) {
				//getGoodsDetailedInfo
				int id=json.getInt("id");
				String sql="select * from goods where id=?";
				PreparedStatement prep=connection.prepareStatement(sql);
				prep.setInt(1, id);
				ResultSet rst=prep.executeQuery();
				if(rst.next()) {
					map.put("imgPaths", GoodsUtil.transGoodsInfoImagePaths(rst.getString("detailedImgPaths"), id));
					map.put("args", GoodsUtil.transGoodsArgs(rst.getString("args")));
				}
				else
					map.put("code", 0);
				prep.close();
				rst.close();
			}
			else if(dataType==3) {
				//getqas
				int id=json.getInt("id");
				String sql="select * from qa where goodsId=?";
				PreparedStatement prep=connection.prepareStatement(sql);
				prep.setInt(1, id);
				ResultSet rst=prep.executeQuery();
				int rowCount=0;
				Map<Integer, Object> qas=new HashMap<>();
				while(rst.next()) {
					rowCount++;
					Map<String, Object> item=new HashMap<>();
					item.put("question", rst.getString("question"));
					item.put("answer",rst.getString("answer"));
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					String raiseTime=df.format(rst.getTimestamp("raiseTime"));
					item.put("raiseTime", raiseTime);
					Timestamp answerTimee=rst.getTimestamp("answerTime");
					String answerTime=answerTimee==null?"��δ�ش�":df.format(answerTimee);
					item.put("answerTime", answerTime);
					qas.put(rowCount, item);
				}
				map.put("qas", qas);
				map.put("qaNum", rowCount);
			}
			else if(dataType==4) {
				//getRepairInfo
				int id=json.getInt("id");
				String sql="select repairInfo from goods where id=?";
				PreparedStatement prep=connection.prepareStatement(sql);
				prep.setInt(1, id);
				ResultSet rst=prep.executeQuery();
				if(rst.next()) {
					map.put("afterSale", GoodsUtil.transGoodsArgs(rst.getString("repairInfo")));
				}
				else
					map.put("code", 0);
				prep.close();
				rst.close();
			}
			else if(dataType==5) {
				//getSimilarGoods
				int id=json.getInt("id");
				String sql_getargs="select args from goods where id=?";
				PreparedStatement prep=connection.prepareStatement(sql_getargs);
				prep.setInt(1, id);
				ResultSet rst=prep.executeQuery();
				String[] arg=null;
				if(rst.next()) {
					arg=rst.getString("args").split("&;&");
				}
				prep.close();
				rst.close();
				String sql_getSimilar="select * from goods where args like '%"+arg[0]+"%'";
				for(int i=2;i<arg.length;i++) {
					sql_getSimilar+="or args like '%"+arg[i]+"%'";
				}
				sql_getSimilar+=" order by queryTime desc";
				prep=connection.prepareStatement(sql_getSimilar);
				rst=prep.executeQuery();
				int rowCount=0;
				while(rst.next()) {
					if(rst.getInt("id")==id)
						continue;
					rowCount++;
					Map<String, Object> item=new HashMap<>();
					item.put("id",rst.getInt("id"));
					item.put("queryTime", rst.getLong("queryTime"));
					item.put("name", rst.getString("name"));
					item.put("firstImgPath", GoodsUtil.transGoodsInfoImagePaths(rst.getString("roughImgPaths"),rst.getInt(id))[0]);
					item.put("price", rst.getDouble("price"));
					map.put(String.valueOf(rowCount), item);
				}
				System.out.println(map.toString());
				prep.close();
				rst.close();
			}
			else {
				//unknown dataType
				map.put("code", 0);
			}
			DBUtil.closeConnection(connection);
			returnData=JSONObject.fromMap(map);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return returnData;
	}
	public static JSONObject receive(JSONObject json) {
		JSONObject returnData=null;
		Map<String, Object> map=new HashMap<>();
		int dataType=json.getInt("dataType");
		try {
			Connection connection=DBUtil.getConnection();
			if(dataType==4) {
				//receive question
				int id=json.getInt("id");
				String sql="insert into qa(goodsId,question,raiseTime) values(?,?,?)";
				PreparedStatement prep=connection.prepareStatement(sql);
				prep.setInt(1, id);
				prep.setString(2, json.getString("question"));
				System.out.println(json.getString("question"));
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				prep.setObject(3, df.format(new Date()));
				int num=prep.executeUpdate();
				if(num==1)
					map.put("success", 1);
				else
					map.put("success", 0);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		returnData=JSONObject.fromMap(map);
		return returnData;
	}
}
