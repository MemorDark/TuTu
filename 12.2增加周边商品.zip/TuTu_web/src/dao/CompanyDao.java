package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Company;
import util.DBUtil;

public class CompanyDao {
	public static Company Login(String loginname,String loginpwd) {
		Company company=null;
		try {
			Connection connection=DBUtil.getConnection();
			String sql="select * from company where loginname=? and loginpwd=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setString(1, loginname);
			prep.setString(2, loginpwd);
			ResultSet rst=prep.executeQuery();
			if(rst.next()) {
				company=new Company(rst.getInt("id"),rst.getString("address"),rst.getString("tel"),rst.getString("businessRegistrationNo"),
						rst.getString("organizationCode"),rst.getString("taxRegistrationCertificate"),rst.getString("legalPerson"),
						rst.getString("name"),loginname);
			}
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return company;
	}
	public static Company Register(String address,String tel,String businessRegistrationNo,String organizationCode,String taxRegistrationCertificate,
			String legalPerson,String name,String loginName,String loginpwd) {
		Company company=null;
		try {
			Connection connection=DBUtil.getConnection();
			String sql="insert into company(address,tel,businessRegistrationNo,organizationCode,taxRegistrationCertificate,legalPerson,name,loginName,loginpwd) "
					+ "values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setString(1, address);
			prep.setString(2, tel);
			prep.setString(3, businessRegistrationNo);
			prep.setString(4, organizationCode);
			prep.setString(5, taxRegistrationCertificate);
			prep.setString(6, legalPerson);
			prep.setString(7, name);
			prep.setString(8, loginName);
			prep.setString(9, loginpwd);
			prep.execute();
			String sql2="select * from company where businessRegistrationNo=? and organizationCode=? and taxRegistrationCertificate=?";
			PreparedStatement prep2=connection.prepareStatement(sql2);
			prep2.setString(1, businessRegistrationNo);
			prep2.setString(2, organizationCode);
			prep2.setString(3, taxRegistrationCertificate);
			ResultSet rst=prep2.executeQuery();
			rst.next();
			company=new Company(rst.getInt("id"),rst.getString("address"),rst.getString("tel"),rst.getString("businessRegistrationNo"),
					rst.getString("organizationCode"),rst.getString("taxRegistrationCertificate"),rst.getString("legalPerson"),
					rst.getString("name"),rst.getString("loginname"));
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return company;
	}
}
