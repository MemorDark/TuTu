package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import entity.Company;
import entity.Goods;
import util.DBUtil;
import util.GoodsUtil;

public class GoodsDao {
	public static ArrayList<Goods> getAllGoods(int companyId) {
		ArrayList<Goods> goods=null;
		try {
			Connection connection=DBUtil.getConnection();
			String sql="select * from goods where companyId=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setInt(1, companyId);
			ResultSet rst=prep.executeQuery();
			goods=new ArrayList<Goods>();
			while (rst.next()) {
				Goods commodity=new Goods(rst.getInt("id"), rst.getString("name"), rst.getString("roughImgPaths").split(";"), rst.getDouble("price"),
						rst.getInt("companyId"),rst.getString("category"),rst.getString("args"),
						rst.getString("detailedImgPaths").split(";"),rst.getString("repairInfo"));
				goods.add(commodity);
			}
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return goods;
	}
	public static ArrayList<Goods> getAllGoods(Company company){
		return getAllGoods(company.getId());
	}
	public static Goods getGoods(int id) {
		Goods goods=null;
		try {
			Connection connection=DBUtil.getConnection();
			String sql="select * from goods where id=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setInt(1, id);
			ResultSet rst=prep.executeQuery();
			if(rst.next()) {
				goods=new Goods(id, rst.getString("name"), rst.getString("roughImgPaths").split(";"), rst.getDouble("price"),
						rst.getInt("companyId"),rst.getString("category"),rst.getString("args"),
						rst.getString("detailedImgPaths").split(";"),rst.getString("repairInfo"));
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return goods;
	}
	public static int AddGoods(String name, String roughImgPaths, double price, int companyId, String category,
		String args, String detailedImgPaths, String repairInfo) {
		int res=-1;
		try {
			Connection connection=DBUtil.getConnection();//Ӧ����Ƿ���������Ʒ
			String sql="insert into goods(name,roughImgPaths,price,companyId,category,args,detailedImgPaths,repairInfo) values(?,?,?,?,?,?,?,?)";
			String sql2="select * from goods where name=? and companyId=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setString(1, name);
			prep.setString(2, roughImgPaths);
			prep.setDouble(3, price);
			prep.setInt(4, companyId);
			prep.setString(5, category);
			prep.setString(6, args);
			prep.setString(7, detailedImgPaths);
			prep.setString(8, repairInfo);
			prep.execute();
			PreparedStatement prep2=connection.prepareStatement(sql2);
			ResultSet rst=prep2.executeQuery();
			rst.next();
			res=rst.getInt("id");
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	public static int AddGoods(Goods goods) {
		return AddGoods(goods.getName(), GoodsUtil.mergeImgPaths(goods.getRoughImgPaths()), goods.getPrice(), goods.getCompanyId(), goods.getCategory(), goods.getArgs(), 
				GoodsUtil.mergeImgPaths(goods.getDetailedImgPaths()), goods.getRepairInfo());
	}
	
	public static void RemoveGoods(int goodsId) {
		try {
			Connection connection=DBUtil.getConnection();
			String sql="delete from goods where id=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setInt(1, goodsId);
			prep.execute();
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			// TODO: handle exception
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void RemoceGoods(Goods goods) {
		RemoveGoods(goods.getId());
	}
	
	public static void ModifyGoods(int id, String name, String roughImgPaths, double price, String category,
		String args, String detailedImgPaths, String repairInfo) {
		try {
			Connection connection=DBUtil.getConnection();
			String sql="update goods set name=?,roughImgPaths=?,price=?,category=?,args=?,detailedImgPAths=?,repairInfo=? where id=?";
			PreparedStatement prep=connection.prepareStatement(sql);
			prep.setString(1, name);
			prep.setString(2, roughImgPaths);
			prep.setDouble(3, price);
			prep.setString(4, category);
			prep.setString(5, args);
			prep.setString(6, detailedImgPaths);
			prep.setString(7, repairInfo);
			prep.setInt(8, id);
			prep.execute();
			DBUtil.closeConnection(connection);
		} catch (SQLException e) {
			// TODO: handle exception
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static ArrayList<String> getCategorys() {
		ArrayList<String> categorys=null;
		try {
			Connection connection=DBUtil.getConnection();
			Statement stat=connection.createStatement();
			String sql="select * from category";
			ResultSet rst=stat.executeQuery(sql);
			categorys=new ArrayList<String>();
			while(rst.next()) {
				categorys.add(rst.getString("cate"));
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return categorys;
	}
	public static void UploadImg() {
		
	}
}
