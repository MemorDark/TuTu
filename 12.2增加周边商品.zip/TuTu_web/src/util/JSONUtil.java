package util;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

public class JSONUtil {
	public static JSONObject transRequestToJson(HttpServletRequest request) throws Exception {
		String postdata=getPostData(request.getInputStream(), request.getContentLength(), null);
		JSONObject json=JSONObject.fromObject(postdata);
		if(json==null)
			throw new Exception("����Ϊ��");
		return json;
	}
	private static String getPostData(InputStream in, int size, String charset) {
        if (in != null && size > 0) {
            byte[] buf = new byte[size];
            try {
                in.read(buf);
                if (charset == null || charset.length() == 0)
                    return new String(buf);
                else {
                    return new String(buf, charset);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
