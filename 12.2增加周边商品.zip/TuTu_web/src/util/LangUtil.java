package util;

public class LangUtil {
	public static boolean jugPrice(String price) {
		if(price.equals("")||price==null)
			return false;
		int pointCount=0;
		for(int i=0;i<price.length();i++) {
			char ch=price.charAt(i);
			if(!(ch>='0'&&ch<='9'||ch=='.')) {
				return false;
			}
			else if(ch=='.') {
				pointCount++;
				if(pointCount>1)
					return false;
			}
		}
		return true;
	}
}
