package util;

public class ErrorUtil {
	public static String CreateJavaScriptError(String msg,String url) {
		String res="<script type=\"text/javascript\">" + 
				"alert(\""+
				msg+
				"\");window.location=\""+
				url+
				"\"</script>";
		return res;
	}
}
