package util;

import java.util.HashMap;
import java.util.Map;

public class GoodsUtil {
	public static String[] transGoodsInfoImagePaths(String paths,int id) {
		String[] path=paths.split("&;&");
		for(int i=0;i<path.length;i++) {
			path[i]="http://127.0.0.1:8080/TuTu_web/Image/goodsinfo/"+String.valueOf(id)+"/"+path[i];
		}
		return path;
	}
	public static String mergeImgPaths(String[] paths) {
		String path="";
		if(paths.length==0||paths==null)
			return path;
		for(int i=1;i<paths.length;i++) {
			path+=";"+paths[i];
		}
		return path;
	}
	public static Map<Integer,String[]> transGoodsArgs(String arg) {
		String[] str=arg.split("&;&");
		Map<Integer,String[]> map=new HashMap<>();
		for(int i=0;i<str.length;i+=2) {
			map.put(i/2, new String[]{str[i],str[i+1]});
		}
		return map;
	}
}
