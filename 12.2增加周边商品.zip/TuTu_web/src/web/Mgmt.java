package web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CompanyDao;
import dao.GoodsDao;
import entity.Company;
import util.ErrorUtil;
import util.LangUtil;

@WebServlet("/Mgmt")
public class Mgmt extends HttpServlet {
    public Mgmt() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		String uri=request.getRequestURI();
		String path=uri.substring(uri.lastIndexOf("/"),uri.lastIndexOf("."));
		System.out.println(path);
		if("/login".equals(path)) {
			String loginname=request.getParameter("loginname");
			String loginpwd=request.getParameter("loginpwd");
			Company company=CompanyDao.Login(loginname, loginpwd);
			if(company!=null) {
				request.getSession().setMaxInactiveInterval(0);
				request.getSession().setAttribute("loginCompany", company);
				response.sendRedirect("main.jsp");
			}//��¼�ɹ�
			else {
				PrintWriter pw=response.getWriter();
				pw.print("<script>alert('�û������������');window.document.location.href='login.jsp';</script>");
				pw.flush();
				pw.close();
			}//��¼ʧ�ܣ���ʾ
		}
		else if("/logout".equals(path)) {
			request.getSession().removeAttribute("loginname");
			response.sendRedirect("index.jsp");
		}
		else if("/delete".equals(path)) {
			int id=Integer.parseInt(request.getParameter("id"));
			//GoodsDao.RemoveGoods(id);
		}
		else if("/addGoods".equals(path)) {
			int companyId=Integer.parseInt(request.getParameter("companyId"));
			String goodsName=request.getParameter("goodsName").toString();
			String price=request.getParameter("price");
			if(!LangUtil.jugPrice(price)) {
				PrintWriter pw=response.getWriter();
				pw.print(ErrorUtil.CreateJavaScriptError("�۸��ʽ��������������","addGoods.jsp"));
				System.out.println("priceError");
				pw.close();
				return;
			}
			double realprice=Double.parseDouble(request.getParameter("price"));
			String category=request.getParameter("category");
			String args=request.getParameter("args");
			String repairInfo=request.getParameter("repqirInfo");
			GoodsDao.AddGoods(goodsName, null, realprice, companyId, category, args, null, repairInfo);
		}
	}
}
