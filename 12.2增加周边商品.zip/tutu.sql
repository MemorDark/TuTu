-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2018-12-02 13:18:06
-- 服务器版本： 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tutu`
--

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cate` varchar(10) NOT NULL DEFAULT '',
  `items` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`cate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`cate`, `items`) VALUES
('数码产品', NULL),
('电器', NULL),
('耗材', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginpwd` varchar(16) DEFAULT NULL,
  `managepwd` varchar(16) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `tel` varchar(11) DEFAULT NULL,
  `businessRegistrationNo` varchar(18) DEFAULT NULL,
  `organizationCode` varchar(9) DEFAULT NULL,
  `taxRegistrationCertificate` varchar(15) DEFAULT NULL,
  `legalPerson` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `loginName` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `company`
--

INSERT INTO `company` (`id`, `loginpwd`, `managepwd`, `address`, `tel`, `businessRegistrationNo`, `organizationCode`, `taxRegistrationCertificate`, `legalPerson`, `name`, `loginName`) VALUES
(1, '123456', '123456', 'xx省xx市xx街道xx路xx号', '12345678902', 'dsfdf5r5g42fdgs', '1f65sd4fr', 'd45sf52d41g5sd4', '张三', 'xx公司', 'zhangsan'),
(2, '123456', '123456', 'ss省ss市ss街道ss路ss号', '12345678902', 'dsfdf5r5g42fdgs', '1f65sd4fr', 'd45sf52d41g5sd4', '李四', 'ss公司', 'accountlisi');

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT 'unknown',
  `roughImgPaths` varchar(60) NOT NULL,
  `price` decimal(6,2) NOT NULL DEFAULT '0.00',
  `companyId` int(11) NOT NULL,
  `category` varchar(10) NOT NULL,
  `args` varchar(200) DEFAULT NULL,
  `detailedImgPaths` varchar(200) NOT NULL,
  `repairInfo` varchar(150) DEFAULT NULL,
  `queryTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`id`, `name`, `roughImgPaths`, `price`, `companyId`, `category`, `args`, `detailedImgPaths`, `repairInfo`, `queryTime`) VALUES
(1, '打印机', '1.jpg&;&2.jpg&;&6.jpg', '12.34', 1, '电器', '品牌&;&佳能&;&型号&;&MP288&;&功能&;&复印 打印 扫描&;&接口类型&;&USB&;&颜色&;&黑色 白色 蓝色&;&最大幅面&;&A4', '1.jpg&;&2.jpg', '厂家地址&;&xx省xx市xx街道xx路xx号&;&厂家电话&;&12345678900&;&售后网址&;&www.xxxx.com', 27),
(2, '墨盒', '1.jpg&;&2.jpg&;&6.jpg', '23.45', 1, '耗材', '适用型号&;&MP288&;&适用品牌&;&佳能', '1.jpg&;&2.jpg&;&6.jpg', 'XXXX&;&XXXX&;&XXXX&;&&XXXX', 1),
(3, '墨盒2', '1.jpg&;&2.jpg&;&6.jpg', '23.45', 1, '耗材', '适用型号&;&MP288&;&适用品牌&;&佳能', '1.jpg&;&2.jpg&;&6.jpg', 'XXXX&;&XXXX&;&XXXX&;&&XXXX', 0),
(4, '墨盒3', '1.jpg&;&2.jpg&;&6.jpg', '23.45', 1, '耗材', '适用型号&;&MP288&;&适用品牌&;&佳能', '1.jpg&;&2.jpg&;&6.jpg', 'XXXX&;&XXXX&;&XXXX&;&&XXXX', 15);

-- --------------------------------------------------------

--
-- 表的结构 `qa`
--

CREATE TABLE IF NOT EXISTS `qa` (
  `goodsId` int(11) NOT NULL,
  `question` varchar(50) NOT NULL,
  `answer` varchar(100) DEFAULT '',
  `raiseTime` datetime NOT NULL,
  `answerTime` datetime DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `qa`
--

INSERT INTO `qa` (`goodsId`, `question`, `answer`, `raiseTime`, `answerTime`, `id`) VALUES
(1, '保修期多长？', '1年', '2018-11-07 00:00:00', '2018-11-17 00:00:00', 1),
(1, 'sfgdfgdfkg', '', '2018-11-27 21:43:38', NULL, 16),
(1, '碎掉了关键是感受到', '', '2018-11-27 21:53:52', NULL, 18);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
