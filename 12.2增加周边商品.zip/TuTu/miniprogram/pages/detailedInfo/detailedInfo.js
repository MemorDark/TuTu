// miniprogram/pages/detailedInfo/detailedInfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodsId:0,
    images:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      goodsId: options.id
    });
    var that=this;
    wx.request({
      url: 'http://127.0.0.1:8080/TuTu_web/dataInterface.jsp',
      method:'POST',
      header: {
        "Content-Type": "applciation/json"
      },
      data: {
        dataType:2,
        id: this.data.goodsId
      },
      success:function(res){
        console.log(res.data);
        var args=res.data.args;
        var imgPaths=res.data.imgPaths;
        var i=0;
        var imgItems={};
        while(imgPaths[i]!=null){
          imgItems[i]={};
          imgItems[i].path=imgPaths[i];
          i++;
        }
        that.setData({
          args:args,
          imgItems:imgItems
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onLoadImg: function (e) {
    var $width = e.detail.width,
      $height = e.detail.height;
    var screenWidth;
    wx.getSystemInfo({
      success: function (res) {
        screenWidth = res.windowWidth;
      }
    })
    var images = this.data.images;
    images[e.target.dataset.index] = {
      imgWidth: screenWidth,
      imgHeight: $height * screenWidth / $width
    }
    this.setData({
      images: images
    });
  }
})