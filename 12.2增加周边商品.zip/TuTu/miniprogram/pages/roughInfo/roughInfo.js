// miniprogram/pages/roughInfo/roughInfo.js
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    goodsId:1,
    goodsName:"",
    goodPrice:0,
    imgWidth: 0,
    imgHeight: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      goodsId:options.id
    });
    var that = this;
    wx.request({
      url:"http://127.0.0.1:8080/TuTu_web/dataInterface.jsp",
      method:'POST',
      header:{
        "Content-Type": "applciation/json"
      },
      data:{
        dataType:1,
        id:this.data.goodsId
      },
      success:function(res){
        console.log("request success");
        console.log(res.data);
        if(res.code==0){//访问失败
          console.log("getdata failed")
          wx.redirectTo({
            url: '../index/index'
          })
        }
        else{
          console.log("getdata success");
          that.setData({
            goodsName:res.data.name,
            goodsImagePaths:res.data.roughImgPaths,
            goodsPrice:res.data.price
          })
        }
      },
      fail:function(){
        console.log("request failed");
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onBtnBack:function(){
    wx.redirectTo({
      url: '../index/index'
    })
  },
  onLoadImg: function (e) {
    var $width = e.detail.width,$height = e.detail.height;
    var screenWidth=wx.getSystemInfoSync().windowWidth;
    if (this.data.imgHeight < $height * screenWidth / $width){
      this.setData({
        imgHeight: $height * screenWidth / $width//以最高图片为准
      });
    }
  },
  onLookDetailedInfoClick: function () {
    wx.navigateTo({
      url: '../detailedInfo/detailedInfo?id=' + this.data.goodsId
    })
  },
  onRepairClick:function(){
    wx.navigateTo({
      url: '../repair/repair?id=' + this.data.goodsId
    })
  },
  onAfterSaleClick:function(){
    wx.navigateTo({
      url: '../afterSale/afterSale?id=' + this.data.goodsId
    })
  },
  onSimilarGoodsClick:function(){
    wx.navigateTo({
      url: '../similarGoods/similarGoods?id='+this.data.goodsId
    })
  }
})